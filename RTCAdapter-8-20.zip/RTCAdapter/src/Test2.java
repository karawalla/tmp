import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.ILiteral;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.Identifier;


public class Test2 {

	public static void main(String[] args) {
		String jazzUrl = "https://192.168.0.4:9443/ccm/";
		String projectAreaName = "Demo2";
		System.out.println("Connecting to RTC");
		try {
			boolean connected = RTCManager.connect("karawalla", "letmein", jazzUrl);
			if(connected){
				RTCManager.loadProjectAreaByname(projectAreaName);
				
				List<IAttribute> attrs = RTCManager.getAttributesForDefects();
				
				IWorkItem wi = RTCManager.getWorkItemById("49");
				IWorkItem eWI = RTCManager.getEditableWorkItem(wi);
				
				for (IAttribute attr : attrs) {
					Object fieldValue = wi.getValue(attr);
					//System.out.println(attr.getAttributeType() + "-" + fieldValue);
					
					try {
						if(attr.getDisplayName().equalsIgnoreCase("app code")){
							System.out.println(RTCManager.isEnumeration(attr));
							//RTCManager.printEnumerationLiteral(attr);
							//Object fieldValue = wi.getValue(attr);
							
							String enumValue = RTCManager.getMatchingEnumerationLiteralName(attr,  fieldValue );
							System.out.println(enumValue);
							ArrayList valueArr = new ArrayList();
							valueArr.add(RTCManager.getMatchingEnumerationLiteral(
									attr, "CNAV1").getIdentifier2());
							eWI.setValue(
									attr,
									valueArr);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
				RTCManager.disconnect();
			}
			else
				System.out.println("Connection Failed to:" + jazzUrl);
			
		} catch (Exception e) { 
			e.printStackTrace();
		}

	}

}
