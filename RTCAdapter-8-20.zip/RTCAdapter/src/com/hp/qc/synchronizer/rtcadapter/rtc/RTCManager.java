package com.hp.qc.synchronizer.rtcadapter.rtc;

import java.net.URI;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.james.mime4j.field.datetime.DateTime;
import org.eclipse.core.runtime.IProgressMonitor;

import sun.nio.cs.ext.MacThai;

import com.hp.qc.synchronizer.adapters.core.AdapterLogger;
import com.hp.qc.synchronizer.adapters.exceptions.AdapterException;
import com.hp.qc.synchronizer.adapters.exceptions.FatalAdapterException;
import com.hp.qc.synchronizer.rtcadapter.RTCDefectManager;
import com.hp.qc.synchronizer.schema.ListFieldSchema;
import com.hp.qc.synchronizer.schema.FieldSchema.FieldType;
import com.ibm.icu.text.DateFormat;
import com.ibm.icu.text.SimpleDateFormat;
import com.ibm.team.foundation.common.text.XMLString;
import com.ibm.team.process.client.IProcessClientService;
import com.ibm.team.process.common.IProcessArea;
import com.ibm.team.process.common.IProjectArea;
import com.ibm.team.repository.client.IItemManager;
import com.ibm.team.repository.client.ITeamRepository;
import com.ibm.team.repository.client.TeamPlatform;
import com.ibm.team.repository.client.internal.ItemManager;
import com.ibm.team.repository.common.IContributor;
import com.ibm.team.repository.common.IContributorHandle;
import com.ibm.team.repository.common.IItem;
import com.ibm.team.repository.common.IItemHandle;
import com.ibm.team.repository.common.TeamRepositoryException;
import com.ibm.team.repository.common.model.ItemHandle;
import com.ibm.team.workitem.client.IAuditableClient;
import com.ibm.team.workitem.client.IDetailedStatus;
import com.ibm.team.workitem.client.IQueryClient;
import com.ibm.team.workitem.client.IWorkItemClient;
import com.ibm.team.workitem.client.IWorkItemWorkingCopyManager;
import com.ibm.team.workitem.client.WorkItemOperation;
import com.ibm.team.workitem.client.WorkItemWorkingCopy;
import com.ibm.team.workitem.common.IWorkItemCommon;
import com.ibm.team.workitem.common.expression.AttributeExpression;
import com.ibm.team.workitem.common.expression.Expression;
import com.ibm.team.workitem.common.expression.IQueryableAttribute;
import com.ibm.team.workitem.common.expression.IQueryableAttributeFactory;
import com.ibm.team.workitem.common.expression.QueryableAttributes;
import com.ibm.team.workitem.common.expression.Term;
import com.ibm.team.workitem.common.internal.rest.IWorkItemRestService.GetDynamicAttributesPropertiesDescriptors;
import com.ibm.team.workitem.common.model.AttributeOperation;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.IAttributeHandle;
import com.ibm.team.workitem.common.model.ICategory;
import com.ibm.team.workitem.common.model.ICategoryHandle;
import com.ibm.team.workitem.common.model.IDeliverable;
import com.ibm.team.workitem.common.model.IEnumeration;
import com.ibm.team.workitem.common.model.ILiteral;
import com.ibm.team.workitem.common.model.IPriority;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.IWorkItemHandle;
import com.ibm.team.workitem.common.model.IWorkItemType;
import com.ibm.team.workitem.common.model.Identifier;
import com.ibm.team.workitem.common.model.ItemProfile;
import com.ibm.team.workitem.common.query.IQueryResult;
import com.ibm.team.workitem.common.query.IResolvedResult;

public class RTCManager {

	private static RTCManager _instance = null;
	public static IProgressMonitor _monitor = new SysOutProgressMonitor();
	public static AdapterLogger _logger = null;
	private static ITeamRepository _repo;
	private static IProjectArea _projectArea;
	private static boolean _isProjectAreaLoaded;
	private static IWorkItemClient _workItemClient;
	private static IWorkItemCommon _workItemCommon;
	private static IAuditableClient _auditableClient;

	private RTCManager() {
	}

	public static RTCManager getInstance(AdapterLogger logger) {
		if (_instance == null) {
			_instance = new RTCManager();
			_logger = logger;
		}

		return _instance;
	}

	public static void setLogger(AdapterLogger logger) {
		_logger = logger;
	}

	public static boolean connect(String userName, String password,
			String jazzUrl) {
		boolean connected = false;
		TeamPlatform.startup();
		try {
			_monitor.subTask("Connecting to RTC url:\"" + jazzUrl + "\"");
			ITeamRepository repo = new TeamConnector().login(userName,
					password, jazzUrl);
			_monitor.subTask("Connecting to RTC url:\"" + jazzUrl + "\"");
			_repo = repo;
			_workItemClient = (IWorkItemClient) _repo
					.getClientLibrary(IWorkItemClient.class);
			_workItemCommon = (IWorkItemCommon) _repo
					.getClientLibrary(IWorkItemCommon.class);
			_auditableClient = (IAuditableClient) _repo
					.getClientLibrary(IAuditableClient.class);
			connected = true;
		} catch (Exception e) {
			connected = false;
			e.printStackTrace();
			System.exit(1);
		}
		return connected;
	}

	// PROJECT AREA API
	public static void loadProjectAreaByname(String projectAreaName) {
		IProcessClientService processClientService = (IProcessClientService) _repo
				.getClientLibrary(IProcessClientService.class);
		URI projectAreaURI = URI.create(projectAreaName.replaceAll(" ", "%20"));
		IProjectArea projectArea = null;
		_isProjectAreaLoaded = false;
		_projectArea = null;
		try {
			projectArea = (IProjectArea) processClientService.findProcessArea(
					projectAreaURI, null, null);
		} catch (Exception e) {
			throw new FatalAdapterException(
					"Fatal Exception. Cannot Connect To project Area."
							+ projectAreaName, e);
		}

		if (projectArea == null) {
			throw new FatalAdapterException(
					"Fatal Exception. Cannot Connect To project Area."
							+ projectAreaName);
		}

		_projectArea = projectArea;
		_isProjectAreaLoaded = true;
	}

	public static boolean isProjectAreaLoaded() {
		return _isProjectAreaLoaded;
	}

	// PROJECT ATTRIBUTES API

	public static List<String> getRequiredAttributes() {
		try {
			IWorkItemType workItemType = _workItemClient.findWorkItemType(
					_projectArea, "defect", _monitor);
			IWorkItemHandle handle = _workItemClient
					.getWorkItemWorkingCopyManager().connectNew(workItemType,
							_monitor);
			WorkItemWorkingCopy wc = _workItemClient
					.getWorkItemWorkingCopyManager().getWorkingCopy(handle);
			IWorkItem workItem = wc.getWorkItem();

			// workItemClient.
			List<String> listProperties = _workItemClient
					.findRequiredProperties(workItem, _monitor); // findTags(HpRTCManager.projectArea,
																	// HpRTCManager._monitor);

			for (String item : listProperties) {
				// listFieldSchema.addValue(item.getName());
				System.out.println(item.toLowerCase());
			}

			return listProperties;
		} catch (TeamRepositoryException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static List<IAttribute> getAttributesForDefects() {
		_monitor.subTask("Getting Defect Attributes:" + _projectArea.getName());

		List<IAttribute> defectAttributes = new ArrayList<IAttribute>();
		try {
			List<IAttribute> projectAttributes = _workItemClient
					.findAttributes(_projectArea, _monitor);

			List<IWorkItem> defects = getAllDefectsForLoadedProject();
			IWorkItem defect = null;

			if (defects.size() == 0) {
				for (Iterator<IAttribute> iterator = projectAttributes
						.iterator(); iterator.hasNext();) {
					IAttribute iAttribute = (IAttribute) iterator.next();
					defectAttributes.add(iAttribute);
				}
			} else {
				defect = defects.get(0);

				_monitor.subTask("Defect is:" + defect.getHTMLSummary());
				for (Iterator<IAttribute> iterator = projectAttributes
						.iterator(); iterator.hasNext();) {
					IAttribute iAttribute = (IAttribute) iterator.next();
					if (defect.hasAttribute(iAttribute)) {
						_monitor.subTask("Defect Has attribute Name: "
								+ iAttribute.getDisplayName() + " and type:"
								+ iAttribute.getAttributeType());
						defectAttributes.add(iAttribute);
					}
				}
			}

		} catch (TeamRepositoryException e) {
			throw new FatalAdapterException(
					"Failed to retrieve defect attributes for:"
							+ _projectArea.getName(), e);
		}

		return defectAttributes;
	}

	public static List<IAttribute> getAttributesForLoadedProject() {
		_monitor.subTask("Getting Attributes:" + _projectArea.getName());
		List<IAttribute> builtInAttributes = new ArrayList<IAttribute>();

		IWorkItemClient workItemClient = (IWorkItemClient) _repo
				.getClientLibrary(IWorkItemClient.class);
		IWorkItemCommon workItemCommon = (IWorkItemCommon) _repo
				.getClientLibrary(IWorkItemCommon.class);

		try {

			builtInAttributes = workItemCommon.findAttributes(_projectArea,
					_monitor);
			/*
			 * List<IAttributeHandle> builtInAttributeHandles =
			 * workItemClient.findBuiltInAttributes(_projectArea, _monitor);
			 * _monitor.subTask("Retrieved builtin Attributes:" +
			 * _projectArea.getName()); for (Iterator<IAttributeHandle> iterator
			 * = builtInAttributeHandles.iterator(); iterator.hasNext();){
			 * 
			 * IAttributeHandle attributeHandle =
			 * (IAttributeHandle)iterator.next();
			 * _monitor.subTask("Gathering info for:" +
			 * attributeHandle.getItemId()); IAttribute iAttribute =
			 * (IAttribute)
			 * _repo.itemManager().fetchCompleteItem(attributeHandle,
			 * IItemManager.DEFAULT, _monitor);
			 * builtInAttributeHandles.add(iAttribute); }
			 */
		} catch (Exception e) {
			throw new FatalAdapterException(
					"Failed to retrieve attributes for:"
							+ _projectArea.getName(), e);
		}

		_monitor.subTask("Completed retrieving built in attributes:"
				+ builtInAttributes.size());
		return builtInAttributes;
	}

	// WORK ITEM API
	public static List<IWorkItem> getAllDefectsForLoadedProject() {
		List<IWorkItem> defects = new ArrayList<IWorkItem>();
		IQueryableAttributeFactory queryableAttributeFactory = QueryableAttributes
				.getFactory(IWorkItem.ITEM_TYPE);
		IAuditableClient auditableClient = (IAuditableClient) _repo
				.getClientLibrary(IAuditableClient.class);
		try {
			IQueryableAttribute wiTypeAttribute = queryableAttributeFactory
					.findAttribute(_projectArea, IWorkItem.TYPE_PROPERTY,
							auditableClient, _monitor);
			IQueryableAttribute wiProjectAreaAttribute = queryableAttributeFactory
					.findAttribute(_projectArea,
							IWorkItem.PROJECT_AREA_PROPERTY, auditableClient,
							_monitor);

			Expression matchingDefectWIs = new AttributeExpression(
					wiTypeAttribute, AttributeOperation.EQUALS, "defect");
			Expression matchingProjectArea = new AttributeExpression(
					wiProjectAreaAttribute, AttributeOperation.EQUALS,
					_projectArea);

			IQueryClient queryClient = _workItemClient.getQueryClient();

			Term term = new Term(Term.Operator.AND);
			term.add(matchingProjectArea);
			term.add(matchingDefectWIs);

			IQueryResult<IResolvedResult<IWorkItem>> results = queryClient
					.getResolvedExpressionResults(_projectArea, term,
							IWorkItem.DEFAULT_PROFILE);

			while (results.hasNext(_monitor)) {
				IResolvedResult<IWorkItem> resolved = results.next(_monitor);
				IWorkItem wi = (IWorkItem) _repo.itemManager()
						.fetchCompleteItem(resolved.getItem(),
								IItemManager.DEFAULT, _monitor);
				defects.add(wi);
				List<IAttributeHandle> customAttrHandles = wi
						.getCustomAttributes();
				for (IAttributeHandle iAttributeHandle : customAttrHandles) {
					IAttribute iAttribute = (IAttribute) _repo.itemManager()
							.fetchCompleteItem(iAttributeHandle,
									IItemManager.REFRESH, _monitor);
					// System.out.println(iAttribute.getDisplayName());
				}
			}

		} catch (TeamRepositoryException e) {
			throw new FatalAdapterException("Failed to get Defects for:"
					+ _projectArea.getName(), e);
		}

		return defects;
	}

	private static class WorkItemInitialization extends WorkItemOperation {
		private String summary;
		private ICategoryHandle category;

		public WorkItemInitialization(String summary, ICategoryHandle category) {
			super("Initializing Defect Work Item");
			this.summary = summary;
			this.category = category;
		}

		@Override
		protected void execute(WorkItemWorkingCopy workingCopy,
				IProgressMonitor monitor) throws TeamRepositoryException {
			IWorkItem workItem = workingCopy.getWorkItem();
			workItem.setHTMLSummary(XMLString.createFromPlainText(summary));
			workItem.setCategory(category);
		}
	}

	public static IWorkItem createNewDefect(String summary) {
		IWorkItem workItem = null;

		try {
			IWorkItemType defectType = _workItemClient.findWorkItemType(
					_projectArea, "defect", _monitor);
			if (defectType == null) {
				throw new AdapterException(
						"Work Item Type:defect could not be found");
			}

			IWorkItemHandle handle = _workItemClient
					.getWorkItemWorkingCopyManager().connectNew(defectType,
							_monitor);
			WorkItemWorkingCopy workItemWorkingCopy = _workItemClient
					.getWorkItemWorkingCopyManager().getWorkingCopy(handle);
			try {
				workItem = workItemWorkingCopy.getWorkItem();
				workItem.setOwner(_repo.loggedInContributor());
				workItem.setCreator(_repo.loggedInContributor());
				if (summary.isEmpty())
					workItem.setHTMLSummary(XMLString
							.createFromPlainText("Test:"
									+ String.format("%d",
											new Random().nextInt(10000))));
				else
					workItem.setHTMLSummary(XMLString
							.createFromPlainText(summary));
				List<ICategory> categories = _workItemClient
						.findCategoriesOfProcessArea(_projectArea,
								ICategory.FULL_PROFILE, _monitor);
				workItem.setCategory(categories.get(categories.size() - 1));
				System.out.println("categpry"
						+ categories.get(categories.size() - 1).getName());

				IDetailedStatus status = workItemWorkingCopy.save(_monitor);
				if (!status.isOK()) {
					System.out.println("Failed to save work item copy.Message="
							+ status.getMessage() + ", Details="
							+ status.getDetails() + ", Code="
							+ status.getCode());
					throw new AdapterException("Failed to save working copy.",
							status.getException());
				}
			} finally {
				_workItemClient.getWorkItemWorkingCopyManager().disconnect(
						handle);
			}

			System.out.println("Created new work Item:" + workItem.getId());
		} catch (TeamRepositoryException e) {
			throw new AdapterException("Failed to create new work item:", e);
		} finally {

		}

		return workItem;
	}

	private static void setFieldValue(IWorkItem workItem,
			List<IAttribute> attrs, String fieldName, Object fieldValue,
			AdapterLogger logger) {
		if (fieldValue == null) {
			return;
		}
		printMessage("RTCMANAGER:updateWorkItemInfo updating workItem:"
				+ workItem.getId() + " for field:" + fieldName, logger);
		for (IAttribute attr : attrs) {
			printMessage("Actual attr"+ attr.getIdentifier() + ", expected " + fieldName, logger);
			if (attr.getIdentifier().equalsIgnoreCase(fieldName)) {
				String attrType = attr.getAttributeType();
				if (attrType.equalsIgnoreCase("tags")) {
					printMessage(
							"RTCMANAGER:updateWorkItemInfo updating workItem:"
									+ workItem.getId() + " for field:"
									+ fieldName + " of type:" + attrType
									+ " with Value:" + fieldValue.toString(),
							logger);
					String[] tagValues = fieldValue.toString().split(",");
					List<String> tags = new ArrayList<String>();
					for (String tagVal : tagValues) {
						tags.add(tagVal.trim().replace(" ", ""));
					}
					workItem.setValue(attr, tags);
				} else if (attrType.equalsIgnoreCase("date")) {
					try {
						Timestamp dateVal = new Timestamp(
								RTCDefectManager.rtcDateFormat.parse(
										fieldValue.toString()).getTime());
						printMessage(
								"RTCMANAGER:updateWorkItemInfo updating workItem:"
										+ workItem.getId() + " for field:"
										+ fieldName + " of type:" + attrType
										+ " with Value:" + dateVal, logger);

						workItem.setValue(attr, dateVal);
					} catch (ParseException e) {

					}
				} else if(attr.getAttributeType().toLowerCase().contains("enumerationlist")){
					try {
						if (RTCManager.isEnumeration(attr)) {
							ArrayList valueArr = new ArrayList();
							valueArr.add(RTCManager.getMatchingEnumerationLiteral(
									attr, fieldValue.toString()).getIdentifier2());
							
							workItem.setValue(
									attr,
									valueArr);
						} 
					} catch (Exception e) {
						printErrorMessage("Failed to set value:" + fieldValue
								+ " to field:" + fieldName + ".Exception:" + e.getLocalizedMessage(), logger);
					}

				}else {
					try {
						if (RTCManager.isEnumeration(attr)) {
							workItem.setValue(
									attr,
									RTCManager.getMatchingEnumerationLiteral(
											attr, fieldValue.toString())
											.getIdentifier2());
						} else {
							workItem.setValue(attr, fieldValue.toString());
						}
					} catch (Exception e) {
						printErrorMessage("Failed to set value:" + fieldValue
								+ " to field:" + fieldName, logger);
					}

				}
				break;
			}
			
		}
	}

	public static boolean isEnumeration(IAttribute attr) {
		IEnumeration<ILiteral> enumeration;

		try {
			enumeration = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);

			List literals = enumeration.getEnumerationLiterals();
			if (literals.size() > 0)
				return true;
			/*
			 * for (Iterator iterator = literals.iterator();
			 * iterator.hasNext();) { ILiteral literal = (ILiteral)
			 * iterator.next();
			 * 
			 * }
			 */
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	public static ILiteral getMatchingEnumerationLiteral(IAttribute attr,
			String litString) {
		IEnumeration<ILiteral> enumeration;

		try {
			enumeration = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);

			List literals = enumeration.getEnumerationLiterals();
			if (literals.size() == 0)
				return null;
			for (Iterator iterator = literals.iterator(); iterator.hasNext();) {
				ILiteral literal = (ILiteral) iterator.next();
				if (literal.getName().equalsIgnoreCase(litString)) {
					return literal;
				}

			}
		} catch (Exception e) {
			return null;
		}

		return null;
	}
	
	
	
	
	
	public static void printEnumerationLiteral(IAttribute attr) {
		IEnumeration<ILiteral> enumeration;

		try {
			enumeration = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);

			List literals = enumeration.getEnumerationLiterals();
			
			for (Iterator iterator = literals.iterator(); iterator.hasNext();) {
				ILiteral literal = (ILiteral) iterator.next();
				System.out.println("Literal:" + literal.getName() + "- " + literal.getIdentifier2());

			}
		} catch (Exception e) {
			
		}
	}

	public static IItem getItem(IItemHandle handle) {

		IItem item;
		try {
			item = _repo.itemManager().fetchCompleteItem(handle,
					IItemManager.DEFAULT, _monitor);

		} catch (TeamRepositoryException e) {
			return null;
		}

		return item;
	}

	public static String getMatchingEnumerationLiteralName(IAttribute attr,
			Identifier<ILiteral> reqLiteral) {
		try {
			IEnumeration<ILiteral> literalEnum = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);
			ILiteral matchingLiteral = literalEnum
					.findEnumerationLiteral(reqLiteral);

			return matchingLiteral.getName();
		} catch (Exception e) {
			return "";
		}
	}
	
	public static String getMatchingEnumerationLiteralName(IAttribute attr,
			Object reqObject) {
		ILiteral matchingLiteral = null;
		
		try {
			IEnumeration<ILiteral> literalEnum = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);
			
			List literals = literalEnum.getEnumerationLiterals();
			Identifier reqLiteral = (Identifier) ((ArrayList)reqObject).get(0);
			for (Iterator iterator = literals.iterator(); iterator.hasNext();) {
				ILiteral literal = (ILiteral) iterator.next();
				System.out.println(literal.getIdentifier2().toString() + " <> " + reqLiteral.toString());
				if (literal.getIdentifier2().toString().equalsIgnoreCase(reqLiteral.toString())){
					matchingLiteral = literal;
					break;
				}
			}
			
			
			return matchingLiteral.getName();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	private static IAttribute findMatchingAttribute(String attrIdentifier,
			List<IAttribute> attrs) {
		for (IAttribute attr : attrs) {
			if (attr.getIdentifier().equalsIgnoreCase(attrIdentifier)) {
				return attr;
			}
		}

		return null;
	}

	public static IWorkItem updateWorkItemInfo(IWorkItem workItem,
			boolean isNew, Map<String, Object> fields,
			WorkItemWorkingCopy workItemWorkingCopy, AdapterLogger logger) {
		printMessage("RTCMANAGER:updateWorkItemInfo updating workItem:"
				+ workItem.getId(), logger);
		List<IAttribute> attrs = getAttributesForDefects();

		try {
			for (String fieldName : fields.keySet()) {
				printMessage("To Update Field :" + fieldName, logger);
				if (fieldName.equalsIgnoreCase("category")) {
					setCategory(workItem, fieldName, fields.get(fieldName)
							.toString(), logger);
				} else if (fieldName.equalsIgnoreCase("summary")) {
					setSummary(workItem, fields.get(fieldName).toString(),
							logger);
				} else if (fieldName.equalsIgnoreCase("creator")
						|| fieldName.equalsIgnoreCase("modifiedBy")
						|| fieldName.equalsIgnoreCase("owner")) {
					setContributor(workItem, fieldName, fields.get(fieldName)
							.toString(), logger);
				} else if (fieldName.equalsIgnoreCase("creationDate")) {
					if (isNew) {
						Timestamp creationDate = new Timestamp(
								RTCDefectManager.rtcDateFormat.parse(
										fields.get(fieldName).toString())
										.getTime());
						workItem.setCreationDate(creationDate);
						printMessage("Setting creation date:" + creationDate,
								logger);
					}
				} else if (fieldName.equalsIgnoreCase("modified")) {
					Timestamp modifiedDate = new Timestamp(
							RTCDefectManager.rtcDateFormat.parse(
									fields.get(fieldName).toString()).getTime());

					IAttribute iDate = _workItemClient
							.findAttribute(_projectArea,
									IWorkItem.MODIFIED_PROPERTY, _monitor);
					workItem.setValue(iDate, modifiedDate);
					printMessage("Setting modified date:" + modifiedDate,
							logger);

				} else if (fieldName.equalsIgnoreCase("internalPriority")) {
					setPriority(workItem, fields.get(fieldName).toString(),
							logger);
				} else {
					setFieldValue(workItem, attrs, fieldName,
							fields.get(fieldName), logger);

				}
			}
			IDetailedStatus status = workItemWorkingCopy.save(_monitor);
			if (!status.isOK()) {
				printErrorMessage(
						"Failed to save work item copy.Message="
								+ status.getMessage() + ", Details="
								+ status.getDetails() + ", Code="
								+ status.getCode(), logger);
				return workItem;
			}

			return (IWorkItem) _repo.itemManager().fetchCompleteItem(workItem,
					IItemManager.DEFAULT, _monitor);
		} catch (Exception e) {
			printErrorMessage(
					"Error occured when updating workItem:" + workItem.getId()
							+ ".Exception " + e.getLocalizedMessage(), logger);
		}

		return workItem;
	}

	private static void setPriority(IWorkItem workItem, String priorityText,
			AdapterLogger logger) {
		IPriority matchingPriority = null;
		try {
			List<IPriority> priorities = _workItemClient.findPriorities(
					_projectArea, _monitor);

			for (IPriority item : priorities) {
				printMessage("Available Priority is:" + item.getName(), logger);
				if (item.getName().equalsIgnoreCase(priorityText)) {
					matchingPriority = item;
					printMessage("Found matching prioirty:" + priorityText,
							logger);
					break;
				}
			}

			if (matchingPriority != null) {
				workItem.setPriority(matchingPriority.getIdentifier2());
			} else {

				printMessage("Could not find priority:"
						+ priorityText
						+ "Settiong it to first priority:"
						+ priorities.get(0).getIdentifier2()
								.getStringIdentifier(), logger);

				workItem.setPriority(priorities.get(0).getIdentifier2());
			}

		} catch (Exception e) {
			printErrorMessage(
					"Failed to get priority matching:" + priorityText, logger);
		}

	}

	public static WorkItemWorkingCopy getWorkItemWorkingCopy() {
		try {
			IWorkItemType defectType = _workItemClient.findWorkItemType(
					_projectArea, "defect", _monitor);

			IWorkItemHandle handle = _workItemClient
					.getWorkItemWorkingCopyManager().connectNew(defectType,
							_monitor);
			WorkItemWorkingCopy workItemWorkingCopy = _workItemClient
					.getWorkItemWorkingCopyManager().getWorkingCopy(handle);

			return workItemWorkingCopy;

		} catch (Exception e) {
			// TODO: handle exception
		}

		return null;
	}

	public static boolean saveWorkingCopy(
			WorkItemWorkingCopy workItemWorkingCopy, AdapterLogger logger) {
		if (workItemWorkingCopy == null) {
			workItemWorkingCopy = getWorkItemWorkingCopy();
		}
		IDetailedStatus status = workItemWorkingCopy.save(_monitor);
		if (!status.isOK()) {
			printErrorMessage(
					"Failed to save work item copy.Message="
							+ status.getMessage() + ", Details="
							+ status.getDetails() + ", Code="
							+ status.getCode(), logger);
			return false;
		}

		return true;
	}

	public static IWorkItem createNewDefect(Map<String, Object> fields,
			AdapterLogger logger) {
		IWorkItem workItem = null;

		try {
			IWorkItemType defectType = _workItemClient.findWorkItemType(
					_projectArea, "defect", _monitor);
			if (defectType == null) {
				throw new AdapterException(
						"Work Item Type:defect could not be found");
			}

			IWorkItemHandle handle = _workItemClient
					.getWorkItemWorkingCopyManager().connectNew(defectType,
							_monitor);
			WorkItemWorkingCopy workItemWorkingCopy = _workItemClient
					.getWorkItemWorkingCopyManager().getWorkingCopy(handle);
			try {
				workItem = workItemWorkingCopy.getWorkItem();
				workItem.setCreator(_repo.loggedInContributor());// in case ALM
																	// property
																	// is not
																	// mapped
				List<ICategory> categories = getCategories(logger);

				if (categories.size() > 0)
					workItem.setCategory(categories.get(0));// In case alm
															// mapping in not
															// set
				else
					printErrorMessage("Failed to retrieve categories", logger);

				workItem = updateWorkItemInfo(workItem, true, fields,
						workItemWorkingCopy, logger);
			} finally {
				_workItemClient.getWorkItemWorkingCopyManager().disconnect(
						handle);
			}

			printMessage("Created new work Item:" + workItem.getId(), logger);
		} catch (TeamRepositoryException e) {
			throw new AdapterException("Failed to create new work item:", e);
		} finally {

		}

		return workItem;
	}

	private static void setSummary(IWorkItem workItem, String summary,
			AdapterLogger logger) {
		printMessage("Setting summmary:" + summary + " for work item:"
				+ workItem.getId(), logger);
		workItem.setHTMLSummary(XMLString.createFromPlainText(summary));
	}

	private static void setContributor(IWorkItem workItem, String fieldName,
			String contrName, AdapterLogger logger) {
		IContributor matchingContributor = null;

		try {
			IContributorHandle[] members = _projectArea.getMembers();
			for (IContributorHandle memberHandle : members) {
				IContributor contributor = (IContributor) _repo.itemManager()
						.fetchCompleteItem(memberHandle, ItemManager.DEFAULT,
								_monitor);
				printMessage("Avail Contributor:" + contributor.getUserId()
						+ " required:" + contrName, logger);
				
				if (contributor.getUserId().equalsIgnoreCase(contrName)) {
					matchingContributor = contributor;
					break;
				}
			}
			if (matchingContributor == null) {
				printMessage("No " + fieldName
						+ " contributor found that matches " + contrName
						+ ". Using logged in contributor:"
						+ _repo.loggedInContributor().getName(), logger);
				if (fieldName.equalsIgnoreCase("creator")) {
					workItem.setCreator(_repo.loggedInContributor());
				} else if (fieldName.equalsIgnoreCase("owner")) {
					workItem.setOwner(_repo.loggedInContributor());
				} else {
					IAttribute modifiedBy = _workItemClient.findAttribute(
							_projectArea, IWorkItem.MODIFIED_BY_PROPERTY,
							_monitor);
					workItem.setValue(modifiedBy, _repo.loggedInContributor());

				}

			} else {
				printMessage("Setting " + fieldName + " contributor "
						+ matchingContributor.getName() + " to work Item:"
						+ workItem.getId(), logger);
				if (fieldName.equalsIgnoreCase("creator")) {
					workItem.setCreator(matchingContributor);
				} else if (fieldName.equalsIgnoreCase("owner")) {
					workItem.setOwner(matchingContributor);
				} else {
					IAttribute modifiedBy = _workItemClient.findAttribute(
							_projectArea, IWorkItem.MODIFIED_BY_PROPERTY,
							_monitor);
					workItem.setValue(modifiedBy, matchingContributor);
				}
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to set contributor name for "
							+ workItem.getId() + " in Project Area:"
							+ _projectArea.getName() + " Exception:"
							+ e.getLocalizedMessage());
		}
	}

	private static void setCategory(IWorkItem workItem, String fieldName,
			String catName, AdapterLogger logger) {
		ICategory matchingCategory = null;
		try {
			List<ICategory> categories = _workItemClient.findCategories(
					_projectArea, ICategory.FULL_PROFILE, _monitor);
			for (ICategory category : categories) {
				if (category.getName().equalsIgnoreCase(catName)) {
					matchingCategory = category;
					break;
				}
				System.out.println("Adding Category:" + category.getName()
						+ ":" + category.getDepth());
			}

			if (matchingCategory == null) {
				if (categories.size() > 0) {
					printMessage("No category found that matches " + catName
							+ ". Using first Category:"
							+ categories.get(0).getName(), logger);
					workItem.setCategory(categories.get(0));
				}

			} else {
				printMessage("Setting category " + matchingCategory.getName()
						+ " to work Item:" + workItem.getId(), logger);
				workItem.setCategory(matchingCategory);
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to set category for workItem:"
							+ workItem.getId() + "in project Area:"
							+ _projectArea.getName() + ". Exception:"
							+ e.getLocalizedMessage());
		}

	}

	public static IWorkItem createNewDefect(String summary, String Category) {
		IWorkItem workItem = null;
		try {
			IWorkItemType workItemType = _workItemClient.findWorkItemType(
					_projectArea, "defect", _monitor);
			if (workItemType == null) {
				throw new AdapterException(
						"Work Item Type:defect could not be found");
			}
			String categoryName = "Releases/RTCAdapter-v1/Iter1";
			List path = Arrays.asList(categoryName.split("/"));
			ICategoryHandle category = _workItemClient.findCategoryByNamePath(
					_projectArea, path, _monitor);
			if (category == null) {
				throw new AdapterException("Category not found:" + categoryName);
			}
			Date date = new Date();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			WorkItemInitialization operation = new WorkItemInitialization(
					"This is test defect:" + dateFormat.format(date), category);
			IWorkItemHandle handle = operation.run(workItemType, _monitor);
			workItem = _auditableClient.resolveAuditable(handle,
					IWorkItem.FULL_PROFILE, _monitor);
			System.out.println("Created new work Item:" + workItem.getId());

		} catch (TeamRepositoryException e) {
			throw new FatalAdapterException(
					"Failed to get Defects Create New defect:"
							+ _projectArea.getName(), e);
		}

		return workItem;
	}

	public static IWorkItem getWorkItemById(String id) {
		IWorkItem workItem = null;

		try {
			workItem = _workItemClient.findWorkItemById(Integer.parseInt(id),
					IWorkItem.FULL_PROFILE, _monitor);

		} catch (Exception e) {
			// TODO: handle exception
		}

		return workItem;
	}

	public static boolean saveWorkItem(IWorkItem workItem, AdapterLogger logger) {
		try {
			IWorkItemWorkingCopyManager wcm = _workItemClient
					.getWorkItemWorkingCopyManager();

			wcm.connect(workItem, IWorkItem.FULL_PROFILE, _monitor);

			WorkItemWorkingCopy wCopy = wcm.getWorkingCopy(workItem);
			IDetailedStatus status = wCopy.save(_monitor);
			if (!status.isOK()) {
				printErrorMessage(
						"Failed to save work item copy.Message="
								+ status.getMessage() + ", Details="
								+ status.getDetails() + ", Code="
								+ status.getCode(), logger);
				return false;
			}

			return true;
		} catch (Exception e) {
			// TODO: handle exception
		}

		return false;
	}

	public static IWorkItem getEditableWorkItem(IWorkItem workItem) {
		try {
			IWorkItemWorkingCopyManager wcm = _workItemClient
					.getWorkItemWorkingCopyManager();

			wcm.connect(workItem, IWorkItem.FULL_PROFILE, _monitor);

			WorkItemWorkingCopy wCopy = wcm.getWorkingCopy(workItem);
			IWorkItem uWItem = wCopy.getWorkItem();
			return uWItem;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return workItem;
	}

	public static IWorkItem updateWorkItem(IWorkItem workItem,
			Map<String, Object> fields, AdapterLogger logger) {
		try {
			logger.info("RTCMANAGER: Updating workItem with Id:"
					+ workItem.getId());

			IWorkItemWorkingCopyManager wcm = _workItemClient
					.getWorkItemWorkingCopyManager();
			wcm.connect(workItem, IWorkItem.FULL_PROFILE, _monitor);

			WorkItemWorkingCopy wCopy = wcm.getWorkingCopy(workItem);
			IWorkItem uWItem = wCopy.getWorkItem();
			workItem = updateWorkItemInfo(uWItem, false, fields, wCopy, logger);
		} catch (Exception e) {
			logger.info("RTCMANAGER: Failed Updating workItem with Id:"
					+ workItem.getId() + " Exception:"
					+ e.getLocalizedMessage());

		}
		return workItem;
	}

	public static IWorkItem updateWorkItem(String id, String summary,
			AdapterLogger logger) {
		IWorkItem workItem = null;
		try {
			logger.info("RTCMANAGER: Updating workItem with Id:" + id);
			workItem = getWorkItemById(id);
			IWorkItemWorkingCopyManager wcm = _workItemClient
					.getWorkItemWorkingCopyManager();
			WorkItemWorkingCopy wCopy = wcm.getWorkingCopy(workItem);
			IWorkItem uWItem = wCopy.getWorkItem();
			uWItem.setHTMLSummary(XMLString.createFromPlainText(summary));
			IDetailedStatus status = wCopy.save(_monitor);
			if (!status.isOK()) {
				logger.info("RTCMANAGER: Failed Updating workItem with Id:"
						+ id + " Issue:" + status.getDetails() + ":Message:"
						+ status.getMessage());
				return workItem;
			}

			return (IWorkItem) _repo.itemManager().fetchCompleteItem(uWItem,
					IItemManager.DEFAULT, _monitor);
		} catch (Exception e) {
			logger.info("RTCMANAGER: Failed Updating workItem with Id:" + id
					+ " Exception:" + e.getLocalizedMessage());
		}

		return workItem;
	}

	public static void deleteWorkItem(String id, AdapterLogger logger) {
		IWorkItem workItem = null;
		try {
			printMessage("RTCMANAGER: Deleting workItem with Id:" + id, logger);
			workItem = getWorkItemById(id);
			IDetailedStatus status = _workItemClient.deleteWorkItem(workItem,
					_monitor);
			if (!status.isOK()) {
				printErrorMessage(
						"RTCMANAGER: Failed Deletion of workItem with Id:" + id
								+ " Issue:" + status.getDetails() + ":Message:"
								+ status.getMessage(), logger);
				return;
			}
			printMessage("RTCMANAGER:Successfully deleting workitem with id:"
					+ id, logger);
		} catch (Exception e) {
			printErrorMessage(
					"RTCMANAGER: Failed Deletion of workItem with Id:" + id
							+ " Exception:" + e.getLocalizedMessage(), logger);
		}
	}

	public static void deleteWorkItem(String id) {
		IWorkItem workItem = null;
		try {
			System.out.println("RTCMANAGER: Deleting workItem with Id:" + id);
			workItem = getWorkItemById(id);
			IDetailedStatus status = _workItemClient.deleteWorkItem(workItem,
					_monitor);
			if (!status.isOK()) {
				System.out
						.println("RTCMANAGER: Failed Deletion of workItem with Id:"
								+ id
								+ " Issue:"
								+ status.getDetails()
								+ ":Message:" + status.getMessage());
			}
		} catch (Exception e) {
			System.out
					.println("RTCMANAGER: Failed Deletion of workItem with Id:"
							+ id + " Exception:" + e.getLocalizedMessage());
		}
	}

	public static IWorkItem updateWorkItem(String id, String summary) {
		IWorkItem workItem = null;
		try {
			System.out.println("RTCMANAGER: Updating workItem with Id:" + id);
			workItem = getWorkItemById(id);
			System.out.println("Found work item with id:" + workItem.getId());
			IWorkItemWorkingCopyManager wcm = _workItemClient
					.getWorkItemWorkingCopyManager();
			System.out.println("Got working copy manager:" + wcm.toString());
			wcm.connect(workItem, IWorkItem.FULL_PROFILE, _monitor);

			WorkItemWorkingCopy wCopy = wcm.getWorkingCopy(workItem);
			System.out.println("Got working copy :" + wCopy.toString());

			IWorkItem uWItem = wCopy.getWorkItem();
			System.out.println("Got working item  :" + uWItem.toString());

			uWItem.setHTMLSummary(XMLString.createFromPlainText(summary));
			IDetailedStatus status = wCopy.save(_monitor);
			if (!status.isOK()) {
				System.out
						.println("RTCMANAGER: Failed Updating workItem with Id:"
								+ id
								+ " Issue:"
								+ status.getDetails()
								+ ":Message:" + status.getMessage());
				return workItem;
			}

			return (IWorkItem) _repo.itemManager().fetchCompleteItem(uWItem,
					IItemManager.DEFAULT, _monitor);
		} catch (Exception e) {
			System.out.println("RTCMANAGER: Failed Updating workItem with Id:"
					+ id + " Exception:" + e.getLocalizedMessage());
		}

		return workItem;
	}

	// FIELD MAPPING API
	public static FieldType getALMFieldTypeFromRTCAttrType(String rtcFieldType) {
		FieldType fieldType = null;

		if (rtcFieldType.equalsIgnoreCase("integer")
				|| rtcFieldType.equalsIgnoreCase("duration")) {
			fieldType = FieldType.NUMBER;
		} else if (rtcFieldType.equalsIgnoreCase("smallstring")
				|| rtcFieldType.equalsIgnoreCase("html")
				|| rtcFieldType.equalsIgnoreCase("mediumhtml")
				|| rtcFieldType.equalsIgnoreCase("uuid")
				|| rtcFieldType.equalsIgnoreCase("comments")) {
			fieldType = FieldType.STRING;
		} else if (rtcFieldType.equalsIgnoreCase("boolean")
				|| rtcFieldType.equalsIgnoreCase("category")
				|| rtcFieldType.equalsIgnoreCase("complexity")
				|| rtcFieldType.equalsIgnoreCase("teamAreaList")
				|| rtcFieldType.equalsIgnoreCase("impact")
				|| rtcFieldType.equalsIgnoreCase("contributor")
				|| rtcFieldType.equalsIgnoreCase("deliverable")
				|| rtcFieldType.equalsIgnoreCase("priority")
				|| rtcFieldType.equalsIgnoreCase("severity")
				|| rtcFieldType.equalsIgnoreCase("statetransitions") ||
				// rtcFieldType.equalsIgnoreCase("projectarea") ||
				rtcFieldType.equalsIgnoreCase("type")) {
			fieldType = FieldType.SINGLE_VAL_LIST;
		} else if (rtcFieldType.equalsIgnoreCase("tags")) {
			fieldType = FieldType.STRING;
		} else if (rtcFieldType.equalsIgnoreCase("timestamp")) {
			fieldType = FieldType.DATE;
		}  else if(rtcFieldType.toLowerCase().contains("enumerationlist")){
			fieldType = FieldType.SINGLE_VAL_LIST;
		}else {
			fieldType = FieldType.STRING;
		}
		return fieldType;
	}

	public static void setSVListItems(IAttribute attr, ListFieldSchema schema,
			AdapterLogger logger) {

		String attrType = attr.getAttributeType().toLowerCase();
		if (attrType.equals("category")) {
			printMessage(
					"Getting Category List Items for:" + attr.getDisplayName(),
					logger);

			setCategoryListItems(schema, logger);
		} else if (attrType.equals("boolean")) {
			setBooleanList(schema, logger);
		} else if (attrType.equals("contributor")) {
			printMessage(
					"Getting Contributor List Items for:"
							+ attr.getDisplayName(), logger);
			setContributorListItems(schema, logger);
		} else {
			printMessage(
					"Getting Generic List Items for:" + attr.getDisplayName(),
					logger);

			setFieldListItems(attr, schema, logger);
		}
	}

	private static void setTagList(ListFieldSchema schema, AdapterLogger logger) {
		try {
			List<String> tags = _workItemClient
					.findTags(_projectArea, _monitor);
			for (String tag : tags) {
				logger.info("Adding Tag:" + tag);
				schema.addValue(tag);
			}

		} catch (Exception e) {
			printErrorMessage(
					"RTCMANAGER: Failed to retrieve tags for "
							+ _projectArea.getName() + ". Exception:"
							+ e.getLocalizedMessage(), logger);
		}
	}

	private static void setFieldListItems(IAttribute attr,
			ListFieldSchema schema, AdapterLogger logger) {
		try {
			IEnumeration<ILiteral> enumeration;

			enumeration = (IEnumeration<ILiteral>) _workItemClient
					.resolveEnumeration(attr, _monitor);
			printMessage(
					"Retrieving enumerations for attribute:"
							+ attr.getDisplayName() + ", "
							+ attr.getAttributeType(), logger);
			List literals = enumeration.getEnumerationLiterals();
			for (Iterator iterator = literals.iterator(); iterator.hasNext();) {
				ILiteral literal = (ILiteral) iterator.next();
				schema.addValue(literal.getName());
			}

		} catch (Exception e) {
		}
	}

	private static void setBooleanList(ListFieldSchema schema,
			AdapterLogger logger) {
		schema.addValue("YES");
		schema.addValue("NO");

	}

	public static void printAttr() {
		List<IAttribute> attrs = getAttributesForDefects();

		for (IAttribute attr : attrs) {

			IEnumeration<ILiteral> enumeration;
			try {
				enumeration = (IEnumeration<ILiteral>) _workItemCommon
						.resolveEnumeration(attr, _monitor);
				System.out.println("Name:" + attr.getDisplayName() + ", "
						+ attr.getAttributeType());
				List literals = enumeration.getEnumerationLiterals();
				for (Iterator iterator = literals.iterator(); iterator
						.hasNext();) {
					ILiteral literal = (ILiteral) iterator.next();
					System.out.println("Lit: " + literal.getName());
				}
			} catch (Exception e) {

			}

		}

	}

	private static void setCategoryListItems(ListFieldSchema schema,
			AdapterLogger logger) {
		try {
			List<ICategory> categories = _workItemClient.findCategories(
					_projectArea, ICategory.FULL_PROFILE, _monitor);
			for (ICategory category : categories) {
				printMessage("Adding Category:" + category.getName(), logger);
				schema.addValue(category.getName());
			}

		} catch (Exception e) {
			printErrorMessage(
					"RTCMANAGER: Failed to retrieve category names for "
							+ _projectArea.getName() + " Exception:"
							+ e.getLocalizedMessage(), logger);
		}
	}

	private static List<ICategory> getCategories(AdapterLogger logger) {
		try {
			List<ICategory> categories = _workItemClient.findCategories(
					_projectArea, ICategory.FULL_PROFILE, _monitor);
			return categories;

		} catch (Exception e) {
			printErrorMessage(
					"RTCMANAGER: Failed to retrieve category names for "
							+ _projectArea.getName() + " Exception:"
							+ e.getLocalizedMessage(), logger);
		}
		return null;
	}

	private static void setDeliverableListItems(ListFieldSchema schema,
			AdapterLogger logger) {
		try {
			List<IDeliverable> deliverables = _workItemClient
					.findDeliverablesByProjectArea(_projectArea, false,
							IDeliverable.FULL_PROFILE, _monitor);

			for (IDeliverable deliverable : deliverables) {
				logger.info("Adding Deliverable:" + deliverable.getName());
				schema.addValue(deliverable.getName());
			}

		} catch (TeamRepositoryException e) {
			printErrorMessage(
					"RTCMANAGER: Failed to retrieve deliverables names for "
							+ _projectArea.getName() + " Exception:"
							+ e.getLocalizedMessage(), logger);
		}
	}

	private static void setContributorListItems(ListFieldSchema schema,
			AdapterLogger logger) {
		try {

			IContributorHandle[] members = _projectArea.getMembers();
			for (IContributorHandle memberHandle : members) {
				IContributor contributor = (IContributor) _repo.itemManager()
						.fetchCompleteItem(memberHandle, ItemManager.DEFAULT,
								_monitor);
				logger.info("Adding contributor to list "
						+ contributor.getName());
				schema.addValue(contributor.getUserId());
			}

		} catch (Exception e) {
			printErrorMessage(
					"RTCMANAGER: Failed to retrieve contributor names for "
							+ _projectArea.getName() + " Exception:"
							+ e.getLocalizedMessage(), logger);
		}
	}

	private static void printMessage(String message, AdapterLogger logger) {
		if (logger == null)
			System.out.println(message);
		else
			logger.info(message);
	}

	private static void printErrorMessage(String message, AdapterLogger logger) {
		if (logger == null)
			System.err.println(message);
		else
			logger.error(message);
	}

	public static void getContributorListItems(AdapterLogger logger) {
		try {

			IContributorHandle[] members = _projectArea.getMembers();
			for (IContributorHandle memberHandle : members) {
				IContributor contributor = (IContributor) _repo.itemManager()
						.fetchCompleteItem(memberHandle, ItemManager.DEFAULT,
								_monitor);
				printMessage(
						"Adding contributor to list " + contributor.getName(),
						logger);
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to retrieve contributor names for "
							+ _projectArea.getName()
							+ " Exception:"
							+ e.getLocalizedMessage());
		}
	}

	public static void getDeliverableListItems() {
		try {
			List<IDeliverable> deliverables = _workItemClient
					.findDeliverablesByProjectArea(_projectArea, true,
							IDeliverable.FULL_PROFILE, _monitor);

			for (IDeliverable deliverable : deliverables) {
				System.out.println(deliverable.getName());
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to retrieve deliverables names for "
							+ _projectArea.getName()
							+ " Exception:"
							+ e.getLocalizedMessage());
		}
	}

	public static void getCategoryListItems() {
		try {
			List<ICategory> categories = _workItemClient.findCategories(
					_projectArea, ICategory.FULL_PROFILE, _monitor);
			for (ICategory category : categories) {
				System.out.println("Adding Category:" + category.getName()
						+ ":" + category.getDepth());
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to retrieve category names. Exception:"
							+ e.getLocalizedMessage());

		}

	}

	public static void getTagListItems() {
		try {
			List<String> tags = _workItemClient
					.findTags(_projectArea, _monitor);
			for (String tag : tags) {
				System.out.println("Adding Tag:" + tag);
			}

		} catch (TeamRepositoryException e) {
			System.out
					.println("RTCMANAGER: Failed to retrieve tag names. Exception:"
							+ e.getLocalizedMessage());

		}

	}

	// get work item info
	public static String getWorkItemModifiedBy(IWorkItem workItem,
			AdapterLogger logger) {
		try {
			IContributorHandle modifiedBy = workItem.getModifiedBy();
			IContributor modifier = (IContributor) _repo.itemManager()
					.fetchCompleteItem(modifiedBy, IItemManager.DEFAULT,
							_monitor);

			return modifier.getUserId();

		} catch (Exception e) {
			printErrorMessage(
					"Failed to get modified by for:" + workItem.getId(), logger);
		}

		return "";
	}

	public static String getWorkItemOwnedBy(IWorkItem workItem,
			AdapterLogger logger) {
		try {
			IContributorHandle ownedBy = workItem.getOwner();
			IContributor owner = (IContributor) _repo.itemManager()
					.fetchCompleteItem(ownedBy, IItemManager.DEFAULT, _monitor);

			return owner.getUserId();

		} catch (Exception e) {
			printErrorMessage("Failed to get owned by for:" + workItem.getId(),
					logger);
		}

		return "";
	}

	public static String getWorkItemPriority(IWorkItem workItem,
			AdapterLogger logger) {
		try {
			Identifier<IPriority> priority = workItem.getPriority();

			IAttribute priorityAttr = _workItemClient.findAttribute(
					_projectArea, IWorkItem.PRIORITY_PROPERTY, _monitor);
			IEnumeration<IPriority> priorityEnum = (IEnumeration<IPriority>) _workItemClient
					.resolveEnumeration(priorityAttr, _monitor);
			IPriority priorityLiteral = priorityEnum
					.findEnumerationLiteral(priority);

			return priorityLiteral.getName();

		} catch (Exception e) {
			printErrorMessage(
					"Failed to get priority by for:" + workItem.getId(), logger);
		}

		return "";
	}

	public static boolean disconnect() {
		boolean isDisconnected = false;
		if (_repo != null && TeamPlatform.isStarted()) {
			try {
				if (_repo.loggedIn()) {
					_repo.logout();
				}
				TeamPlatform.shutdown();
				isDisconnected = true;
			} catch (Exception e) {
				isDisconnected = false;
			}
		}

		return isDisconnected;
	}
}
