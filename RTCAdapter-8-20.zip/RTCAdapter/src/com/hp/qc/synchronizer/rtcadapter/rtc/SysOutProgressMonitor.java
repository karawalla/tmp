package com.hp.qc.synchronizer.rtcadapter.rtc;

import org.eclipse.core.runtime.IProgressMonitor;

public class SysOutProgressMonitor implements IProgressMonitor{

	@Override
	public void beginTask(String name, int totalWork) {
		printMsg("RTC Begin Task", name);
	}

	@Override
	public void done() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void internalWorked(double arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isCanceled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setCanceled(boolean arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setTaskName(String name) {
		printMsg("RTC Set Task Name", name);
	}

	@Override
	public void subTask(String name) {
		printMsg("RTC sub Task", name);
	}

	@Override
	public void worked(int work) {
		// TODO Auto-generated method stub
		
	}

	private void printMsg(String context, String msg){
		if(msg != null && ! "".equals(msg))
			System.out.println(context + ":" + msg);
	}
}
