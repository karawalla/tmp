package com.hp.qc.synchronizer.rtcadapter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hp.qc.synchronizer.adapters.core.AdapterLogger;
import com.hp.qc.synchronizer.adapters.core.BaseRecordDataOrderedSet;
import com.hp.qc.synchronizer.adapters.core.FieldInfo;
import com.hp.qc.synchronizer.adapters.exceptions.AdapterException;
import com.hp.qc.synchronizer.adapters.spi.DefectManager;
import com.hp.qc.synchronizer.adapters.spi.DefectTypeRecord;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.ibm.team.workitem.common.model.IWorkItem;

public class RTCDefectManager implements DefectManager {

	private AdapterLogger logger;
	private static final String RTC_DATE_FORMAT = "EEE MMM dd HH:mm:ss z yyyy";
	private static final String ALM_DATE_FORMAT = "yyyy-mm-dd HH:mm:ss";
	
	public static final SimpleDateFormat rtcDateFormat = new SimpleDateFormat(
			RTC_DATE_FORMAT);
	
	public static final SimpleDateFormat almDateFormat = new SimpleDateFormat(
			ALM_DATE_FORMAT);


	public RTCDefectManager(AdapterLogger logger) {
		logger.info("RTC Defect Manager Invoked");
		this.logger = logger;
	}

	@Override
	public DefectTypeRecord create(Map<String, Object> fields) {
		String fieldStr = "";
		logger.info("RTC-ADAPTER-INFO: Calling create");
		for (String fieldKey : fields.keySet()) {
			fieldStr += fieldKey + "::" + fields.get(fieldKey).toString()
					+ ", ";
		}

		logger.info("Creating defect type: with fields" + fieldStr);
		return new RTCDefectRecord(logger, fields);
	}

	@Override
	public String checkEndpointParams(Map<String, String> arg0) {
		logger.info("RTC-ADAPTER-INFO: Calling DefectTypeRecord.checkEndpointParams");
		return "";
	}

	@Override
	public Date getEndpointTime() {
		logger.info("RTC-ADAPTER-INFO: Calling DefectTypeRecord.getEndpointTime");
		return new Date();
	}

	@Override
	public void setEndpointParams(Map<String, String> arg0) {
		logger.info("RTC-ADAPTER-INFO: Calling DefectTypeRecord.setEndpointParams");
	}

	@Override
	public void getRecordIDs(Date sinceDate, String filter,
			BaseRecordDataOrderedSet idList) throws AdapterException {
		logger.info("RTC-ADAPTER-INFO: Calling DefectTypeRecord.getRecordIDs");

		List<IWorkItem> defects = RTCManager.getAllDefectsForLoadedProject();
		logger.info("Number of RTC defects:" + defects.size());

		for (int i = 0; i < defects.size(); i++) {
			IWorkItem workItem = defects.get(i);
			String id = String.format("%d", workItem.getId());
			RTCDefectRecord record = new RTCDefectRecord(logger, workItem, this);
			logger.info(String.format("Adding item `%s` to list of ids",
					workItem.getId()));
			idList.add(id, record.getVersion());
		}
	}

	public RTCDefectRecord getRecord(String id) {
		IWorkItem workItem = RTCManager.getWorkItemById(id);

		if (workItem != null) {
			return new RTCDefectRecord(logger, workItem, this);
		}
		logger.info("No Work Item found for ID:" + id);
		return null;
	}

	@Override
	public DefectTypeRecord getRecordInterface(String id) {
		logger.info("RTC-ADAPTER-INFO: Calling DefectTypeRecord.getRecordInterface with ID:"
				+ id);

		return getRecord(id);
	}

}
