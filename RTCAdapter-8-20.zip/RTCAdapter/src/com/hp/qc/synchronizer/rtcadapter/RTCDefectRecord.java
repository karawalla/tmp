package com.hp.qc.synchronizer.rtcadapter;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.hp.qc.synchronizer.adapters.core.AdapterLogger;
import com.hp.qc.synchronizer.adapters.core.FieldInfo;
import com.hp.qc.synchronizer.adapters.exceptions.AdapterException;
import com.hp.qc.synchronizer.adapters.exceptions.FatalAdapterException;
import com.hp.qc.synchronizer.adapters.spi.AttachmentHandler;
import com.hp.qc.synchronizer.adapters.spi.DefectTypeRecord;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCConstants;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.ibm.team.repository.common.IItemHandle;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.ICategory;
import com.ibm.team.workitem.common.model.IEnumeration;
import com.ibm.team.workitem.common.model.ILiteral;
import com.ibm.team.workitem.common.model.IPriority;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.Identifier;
import com.sun.corba.se.spi.legacy.connection.GetEndPointInfoAgainException;
import com.sun.xml.internal.ws.message.saaj.SAAJHeader;

public class RTCDefectRecord implements DefectTypeRecord {

	private AdapterLogger logger;

	private IWorkItem _workItem;

	private RTCDefectManager manager;

	public static String fieldNames[] = { RTCConstants.ID,
			RTCConstants.SUMMARY, RTCConstants.LAST_MODIFIED,
			RTCConstants.VERSION , RTCConstants.CREATION_DATE, RTCConstants.PRIORITY};
	
	private static Map<String, String> recordFields = new HashMap<String, String>();

	public RTCDefectRecord(AdapterLogger logger, Map<String, Object> fields) {
		logger.info("RTC-ADAPTER-INFO: Calling RTCDefectRecord:constructor");

		String summary = (String) fields.get("summary");
		logger.info("RTC-ADAPTER-INFO: Creating new defect with summary:"
				+ summary);

		_workItem = RTCManager.createNewDefect(fields, logger);
		recordFields.put(RTCConstants.ID,
				String.format("%d", _workItem.getId()));
		recordFields.put(RTCConstants.VERSION, "1");

		this.logger = logger;
	}

	public RTCDefectRecord(AdapterLogger logger, IWorkItem workItem,
			RTCDefectManager manager) {
		logger.info("RTC-ADAPTER-INFO:Init New defect Record with work item");
		this.manager = manager;
		this.logger = logger;
		_workItem = workItem;
		List<IAttribute> attrs = RTCManager.getAttributesForDefects();
		for (String fieldName : getEntityFieldNames()) {
			String fieldValue = "";
			logger.info("RTC-ADAPTER-INFO:Started Populating Value for field:" + fieldName);
			if(fieldName.equals(RTCConstants.SUMMARY)){
				logger.info("RTC-ADAPTER-INFO:Populated Summary " +_workItem.getHTMLSummary().getPlainText());
				recordFields.put(fieldName, _workItem.getHTMLSummary().getPlainText());
			} else if(fieldName.equals(RTCConstants.ID)){
				logger.info("RTC-ADAPTER-INFO:Populated ID" + _workItem.getId());
				recordFields.put(fieldName, String.format("%d", _workItem.getId()));
			} else if(fieldName.equals(RTCConstants.CREATION_DATE)){
				logger.info("RTC-ADAPTER-INFO:Populating Creation Date" + _workItem.getCreationDate());
				recordFields.put(fieldName, _workItem.getCreationDate().toString());
			} else if(fieldName.equalsIgnoreCase("modified")){
				logger.info("RTC-ADAPTER-INFO:Populated Modified Date" + _workItem.modified());
				recordFields.put(fieldName, _workItem.modified().toString());
			} 
			else if(fieldName.equals(RTCConstants.PRIORITY)){
				String priority = RTCManager.getWorkItemPriority(workItem, logger);
				logger.info("RTC-ADAPTER-INFO:Populated Priority:" + priority);
				recordFields.put(fieldName,priority);
			} else if(fieldName.equalsIgnoreCase("modifiedBy")){
				String modifiedByName =  RTCManager.getWorkItemModifiedBy(_workItem, logger);
				logger.info("RTC-ADAPTER-INFO:Populated modified:" + modifiedByName);
				recordFields.put(fieldName,modifiedByName);
			} else if(fieldName.equalsIgnoreCase("owner")){
				String ownedByName =  RTCManager.getWorkItemOwnedBy(_workItem, logger);
				logger.info("RTC-ADAPTER-INFO:Populated owner:" + ownedByName);
				recordFields.put(fieldName,ownedByName);
			} else {
				String fValue = getFieldValue(attrs, fieldName, logger);
				logger.info("RTC-ADAPTER-INFO:Populating :" + fieldName + " with field Value:" + fValue);
				recordFields.put(fieldName,fValue);
			}
			
		}

		logger.info("RTC-ADAPTER-INFO:Completed fetching RTC Record with work item" + _workItem.getId());
	}

	private String getFieldValue(List<IAttribute> attrs, String fieldName, AdapterLogger logger2) {
		logger.info("RTC-ADAPTER-INFO:getFieldValue:fieldName:" + fieldName);
		for (IAttribute attr : attrs) {
			if (attr.getIdentifier().equalsIgnoreCase(fieldName)) {
				try {
					logger.info("RTC-ADAPTER-INFO:getFieldValue:fieldName:" + fieldName + ". type:" + attr.getAttributeType());
					
					Object fieldValue = _workItem.getValue(attr);
					if (fieldValue == null) {
						return "";
					}
					logger.info("RTC-ADAPTER-INFO:getFieldValue:fieldName:" + fieldName + ". type:" + attr.getAttributeType() + " field Value:" + fieldValue);
					
					if(attr.getAttributeType().equalsIgnoreCase("date")){
						fieldValue = RTCDefectManager.almDateFormat.parseObject(fieldValue.toString()).toString();
					}else if(attr.getAttributeType().toLowerCase().contains("enumerationlist")){
						String enumValue = RTCManager.getMatchingEnumerationLiteralName(attr, fieldValue);
						logger.info("Enumeration Field :" + fieldName + " has  value:" + enumValue);
						return enumValue;
					} else if(RTCManager.isEnumeration(attr)){
						String enumValue = RTCManager.getMatchingEnumerationLiteralName(attr, (Identifier<ILiteral>) fieldValue);
						logger.info("Enumeration Field :" + fieldName + " has  value:" + enumValue);
						return enumValue;
					}else if(attr.getAttributeType().equalsIgnoreCase("category")){
						ICategory category = (ICategory) RTCManager.getItem((IItemHandle) fieldValue);
						if(category == null){
							return "";
						}
						return category.getName();
					}else if(attr.getAttributeType().equalsIgnoreCase("tags")){
						String fValue = fieldValue.toString().trim();
						return fValue.substring(fValue.indexOf("[")+1,fValue.lastIndexOf("]"));
					}
					
					logger.info("Field :" + fieldName + " has  value:" + fieldValue);
					return "";//fieldValue.toString();
					
				} catch (Exception e) {
					logger.error("Failed to get field value:" + fieldName + " Error:" + e.getLocalizedMessage());
					return "";
				}
			}
			
		}
		
		
		return "";
	}

	public RTCDefectRecord(AdapterLogger logger, RTCDefectManager manager) {
		this.manager = manager;
		this.logger = logger;
	}

	@Override
	public void delete() throws AdapterException, FatalAdapterException {
		RTCManager.deleteWorkItem(getID(), logger);
	}

	@Override
	public Map<String, Object> fetchData(Map<String, FieldInfo> fields)
			throws AdapterException, FatalAdapterException {
		logger.info("RTC-ADAPTER-INFO: Calling RTCDefectRecord:fetchData");
		
		Map<String, Object> fetchedFields = new HashMap<String, Object>();
        String currFieldName = null;
        for (FieldInfo fi : fields.values()) {
            currFieldName = fi.getName();
            logger.info("RTCMANAGER:Fetch Data: field name = " + currFieldName);
            if (this.recordFields.containsKey(currFieldName)) {
             	logger.info("RTC-ADAPTER-INFO:: Fetched Data:" + currFieldName + " = " + this.recordFields.get(currFieldName));
             	
             	if(currFieldName.equals(RTCConstants.CREATION_DATE)){
     				try {
     					fetchedFields.put(currFieldName,RTCDefectManager.almDateFormat.parseObject(this.recordFields.get(currFieldName)));
     					logger.info("RTC-ADAPTER-INFO:Populating Creation Date" + RTCDefectManager.almDateFormat.parseObject(this.recordFields.get(currFieldName)));
         	
     				} catch (ParseException e) {
 						
 					}
     			} else {
     				fetchedFields.put(currFieldName, this.recordFields.get(currFieldName));
     			}
             }
        }
        return fetchedFields;
	}

	@Override
	public AttachmentHandler getAttachementHandler(String arg0)
			throws AdapterException, FatalAdapterException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getID() {
		logger.info("RTC-ADAPTER-INFO: Calling RTCDefectRecord:getID");
		return String.format("%d", _workItem.getId());
	}

	@Override
	public String getVersion() {
		if (recordFields.containsKey(RTCConstants.VERSION)) {
			return recordFields.get(RTCConstants.VERSION).toString();
		}

		return null;
	}

	private String[] getEntityFieldNames() {
		List<IAttribute> defectAttrs = RTCManager.getAttributesForDefects();
		String[] fNames = new String[defectAttrs.size()];
		int i = 0;
		for (IAttribute iAttribute : defectAttrs) {
			fNames[i++] = iAttribute.getIdentifier();
			logger.info("RTCDefectRecord:getEntityFieldNames adding field:"+ iAttribute.getIdentifier());
		}
		
		
		return fNames;
	}

	@Override
	public void update(Map<String, Object> fields) throws AdapterException,
			FatalAdapterException {
		logger.info("RTC-ADAPTER-INFO: Calling RTCDefectRecord:update");
		boolean changed = false;
		for (String fieldName : getEntityFieldNames()) {
			Object fieldValue = fields.get(fieldName);
			if (fieldValue != null) {
				logger.info("RTC-ADAPTER-INFO: Changed:Field" + fieldName + ":"
						+ fieldValue);
				this.recordFields.put(fieldName, fieldValue.toString());
				changed = true;
			}
		}

		if (changed) {
			logger.info("RTC-ADAPTER-INFO:Changed and  Calling updateWorkItem");
			updateWorkItem(fields);
		}

	}

	public void updateWorkItem(Map<String, Object> fields) {
		logger.info("RTC-ADAPTER-INFO: Calling updateWorkItem");
		recordFields.put(RTCConstants.LAST_MODIFIED,
				RTCDefectManager.rtcDateFormat.format(new Date()));
		logger.info("RTC-ADAPTER-INFO:Record Fields info");
		for(String fieldName:recordFields.keySet()){
			logger.info("RTC-ADAPTER-INFO:RF info:" + fieldName + "=" + recordFields.get(fieldName));
		}
		int version = 0;
		if(recordFields.containsKey(RTCConstants.VERSION)){
			version = Integer.parseInt(recordFields.get(RTCConstants.VERSION));
		}
		logger.info("RTC-ADAPTER-INFO:Incrementing version of work item" );
		version++;
		recordFields.put(RTCConstants.VERSION, String.valueOf(version));
		_workItem = RTCManager.updateWorkItem(_workItem,fields,logger);
	/*	for (String fieldName : getEntityFieldNames()) {
			if (recordFields.containsKey(fieldName)) {
				if (fieldName.equals(RTCConstants.SUMMARY)) {
					logger.info("RTC-ADAPTER-INFO:UPDATING WorkItem with summary:"
							+ recordFields.get(RTCConstants.SUMMARY));
					_workItem = RTCManager.updateWorkItem(_workItem,fields,logger);
				}

			}
		}*/
	}

}