package com.hp.qc.synchronizer.rtcadapter;

import java.util.List;

import com.hp.qc.synchronizer.adapters.core.AdapterConnectionData;
import com.hp.qc.synchronizer.adapters.core.AdapterLogger;
import com.hp.qc.synchronizer.adapters.core.EntityType;
import com.hp.qc.synchronizer.adapters.exceptions.AdapterConnectionException;
import com.hp.qc.synchronizer.adapters.exceptions.AdapterException;
import com.hp.qc.synchronizer.adapters.spi.AdapterConnection;
import com.hp.qc.synchronizer.adapters.spi.DefectManager;
import com.hp.qc.synchronizer.adapters.spi.RequirementManager;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCConstants;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.hp.qc.synchronizer.schema.EntitySchemaBuilder;
import com.hp.qc.synchronizer.schema.EntityTypesBuilder;
import com.hp.qc.synchronizer.schema.FieldSchema;
import com.hp.qc.synchronizer.schema.FieldSchema.FieldRequiredLevel;
import com.hp.qc.synchronizer.schema.FieldSchema.FieldType;
import com.hp.qc.synchronizer.schema.ListFieldSchema;
import com.ibm.team.process.common.IProjectArea;
import com.ibm.team.workitem.common.model.IAttribute;
import com.sun.org.apache.bcel.internal.generic.Type;

public class RTCAdapterConnection implements AdapterConnection{

	public static final String CONN_DATA_JAZZ_URL = "RTC Repo URL";
	public static final String CONN_DATA_PROJECT_AREA = "RTC Proj Area";
	private AdapterLogger logger;
	private boolean connected;
	
	
	public RTCAdapterConnection(AdapterLogger logger) {
		this.logger = logger;
	}

	public void connect(AdapterConnectionData connData) {
		logger.info("RTC-ADAPTER-INFO: Calling connect");
		String jazzUrl = connData.getPropertyByName(CONN_DATA_JAZZ_URL);
		String projectAreaName = connData.getPropertyByName(CONN_DATA_PROJECT_AREA);
		logger.info("Connecting to RTC");
		try {
			connected = RTCManager.connect(connData.getUsername(), connData.getPassword(), jazzUrl);
			if(connected){
				logger.info("Connection to:" + jazzUrl + " successful");
				RTCManager.loadProjectAreaByname(projectAreaName);
				logger.info("Connected to Project Area:" + projectAreaName);
			}
			else
				logger.error("Connection Failed to:" + jazzUrl);
			
		} catch (Exception e) { 
			throw new AdapterConnectionException("Error Creating Connection:", e);
		}
	
		logger.info("Connected to RTC:" + jazzUrl + " as User:" + connData.getUsername());
		
	}

	private void printAttrib(IAttribute iAttribute){
		logger.info("Display Name:" + iAttribute.getDisplayName());
		logger.info("Attrib Type:" + iAttribute.getAttributeType());
		logger.info("Attrib iD:" + iAttribute.getIdentifier());
		logger.info("Item Handle:" + iAttribute.getItemHandle());
		logger.info("Item iD:" + iAttribute.getItemId());
		logger.info("Item Type:" + iAttribute.getItemType());
		logger.info("Field Type:" + RTCManager.getALMFieldTypeFromRTCAttrType(iAttribute.getAttributeType()));
	}
	@Override
	public void buildEntitySchema(EntitySchemaBuilder esb, String entType)
			throws AdapterException {
		
		if(entType.equalsIgnoreCase(RTCConstants.TYPE_DEFECT)){
		logger.info("RTC-ADAPTER-INFO: Calling buildEntitySchema");
		List<IAttribute> builtInAttributes = RTCManager.getAttributesForDefects();
		List<String> rqdAttributes = RTCManager.getRequiredAttributes();
		
		logger.info("Creating Field Schema");
		/*FieldSchema field = esb.addListField("Field1", FieldType.SINGLE_VAL_LIST);
		field.setRequiredLevel(FieldRequiredLevel.OPTIONAL);
        field.setReadonly(false);
        field.setDisplayName("List 1");
        field.*/
		
		int i = 0;
		try {
			for(IAttribute attribute:builtInAttributes){
				logger.info("#####################################################");
				logger.info("Adding RTC Field:" + i++ + " :=>" + attribute.getDisplayName() + " to schema");
				printAttrib(attribute);
				logger.info("#####################################################");
				FieldType fieldType = RTCManager.getALMFieldTypeFromRTCAttrType(attribute.getAttributeType());
				if (fieldType.toString().equalsIgnoreCase("SINGLE_VAL_LIST")) {
					ListFieldSchema field = esb.addListField(attribute.getIdentifier(), fieldType);
					field.setRequiredLevel(FieldRequiredLevel.OPTIONAL);
			        field.setReadonly(attribute.isReadOnly());
			        if (attribute.getAttributeType().equalsIgnoreCase("contributor")) {
						field.setReadonly(false);
					}
			        field.setDisplayName(attribute.getDisplayName());
			        if(rqdAttributes.contains(attribute.getIdentifier().toLowerCase())){
						field.setRequiredLevel(FieldRequiredLevel.MANDATORY);
					}
			        RTCManager.setSVListItems(attribute, field, logger);
				}
				else {
					FieldSchema field = esb.addField(attribute.getIdentifier(),fieldType);
					field.setRequiredLevel(FieldRequiredLevel.OPTIONAL);
			        field.setReadonly(false);
			        field.setDisplayName(attribute.getDisplayName());
			        if(rqdAttributes.contains(attribute.getIdentifier())){
						field.setRequiredLevel(FieldRequiredLevel.MANDATORY);
					}
				}
				
				
			}
		} catch (Exception e) {
			logger.error("Error occured in build entity:" + e.getLocalizedMessage());
		}
		logger.info("Complete build schema");
		}
	}

	@Override
	public void checkUserPermitted() throws AdapterException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void declareEntityTypes(EntityTypesBuilder builder)
			throws AdapterException {
		logger.info("RTC-ADAPTER-INFO: Calling declareEntityTypes");
		logger.info("Declare entity types called");
		logger.info("Declaring entity " + RTCConstants.TYPE_DEFECT);
		builder.declareType(RTCConstants.TYPE_DEFECT, EntityType.DEFECT);
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public DefectManager getDefectManager(String entityName) {
		logger.info("RTC-ADAPTER-INFO:getDefectManager:" + entityName);
		try {
			if(entityName.equalsIgnoreCase(RTCConstants.TYPE_DEFECT)){
				logger.info("RTC-ADAPTER-INFO: Calling getDefectManager");
			
				return new RTCDefectManager(logger);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public RequirementManager getRequirementManager(String arg0)
			throws AdapterException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasCreatePermissions(String arg0) throws AdapterException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean hasDeletePermissions(String arg0) throws AdapterException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean hasUpdatePermissions(String arg0) throws AdapterException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isConnected() {
		// TODO Auto-generated method stub
		return connected;
	}

	
}
