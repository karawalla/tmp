package com.hp.qc.synchronizer.rtcadapter;

import java.util.HashMap;
import java.util.Map;

import com.hp.qc.synchronizer.adapters.core.AdapterConnectionData;
import com.hp.qc.synchronizer.adapters.core.AdapterLogger;
import com.hp.qc.synchronizer.adapters.core.EntityType;
import com.hp.qc.synchronizer.adapters.spi.Adapter;
import com.hp.qc.synchronizer.adapters.spi.AdapterConnection;

public class RTCAdapter implements Adapter{


	private AdapterLogger logger;

	public RTCAdapter(AdapterLogger logger) {
		this.logger = logger;
	}

	@Override
	public AdapterConnection connect(AdapterConnectionData connData) {
		logger.info("Initializing connection");
		RTCAdapterConnection conn = new RTCAdapterConnection(logger);
		
		conn.connect(connData);
		logger.info("Completed Connection");
		return conn;
	}

	@Override
	public Map<String, String> getConnectionParams() {
		Map<String, String> params = new HashMap<String, String>();
		params.put(RTCAdapterConnection.CONN_DATA_JAZZ_URL, "");
		params.put(RTCAdapterConnection.CONN_DATA_PROJECT_AREA, "");
		
		return params;
	}

	@Override
	public Map<String, String> getEndpointParams(EntityType arg0) {
		Map<String, String> endPoints = new HashMap<String, String>();
	
		return endPoints;
	}

	@Override
	public String getVersion() {
		// TODO Auto-generated method stub
		return "1.1";
	}

}
