package com.hp.qc.synchronizer.rtcadapter.rtc;

public class RTCSettings {

}
