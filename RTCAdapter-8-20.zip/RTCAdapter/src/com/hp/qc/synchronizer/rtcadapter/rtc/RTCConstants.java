package com.hp.qc.synchronizer.rtcadapter.rtc;

public class RTCConstants {
	public static final String TYPE_DEFECT = "Defect";
	public static final String ID = "Id";
	public static final String SUMMARY = "summary";
	public static final String VERSION = "version";
    public static final String LAST_MODIFIED = "LastModified";
    public static final String CREATION_DATE = "creationDate";
    public static final String PRIORITY = "internalPriority";
}
