package com.hp.qc.synchronizer.rtcadapter.rtc;

import org.eclipse.core.runtime.IProgressMonitor;

import com.ibm.team.repository.client.ITeamRepository;
import com.ibm.team.repository.client.TeamPlatform;
import com.ibm.team.repository.common.TeamRepositoryException;

public class TeamConnector {

	public ITeamRepository login(String userName, String password,
			String jazzUrl, IProgressMonitor monitor) throws TeamRepositoryException {
		final String uname = userName;
		final String pwd = password;
		
		ITeamRepository repository = TeamPlatform.getTeamRepositoryService().getTeamRepository(jazzUrl);
		repository.registerLoginHandler(new ITeamRepository.ILoginHandler(){
			@Override
			public ILoginInfo challenge(ITeamRepository repository) {
				return new ILoginInfo() {
					@Override
					public String getUserId() {
						return uname;
					}
					
					@Override
					public String getPassword() {
						return pwd;
					}
				};
			}
		});
		
		monitor.subTask("Connecting to:" + repository.getRepositoryURI() + ".");
		repository.login(monitor);
		monitor.subTask("Connected to:" + repository.getRepositoryURI());
		return repository;
	}
	
	
	public ITeamRepository login(String userName, String password,
			String jazzUrl) throws TeamRepositoryException{
		return login(userName, password, jazzUrl, RTCManager._monitor);
	}

}
