package com.hp.qc.synchronizer.rtcadapter;

import java.util.ArrayList;
import java.util.List;

import com.hp.qc.synchronizer.adapters.core.AdapterContext;
import com.hp.qc.synchronizer.adapters.spi.Adapter;
import com.hp.qc.synchronizer.adapters.spi.AdapterFactory;

public class RTCAdapterFactory implements AdapterFactory{

	@Override
	public Adapter createAdapter(String arg0, AdapterContext context) {
		Adapter adapter = null;
		adapter = new RTCAdapter(context.getLogger());
		
		return adapter;
	}

	@Override
	public List<String> getAdapterTypes() {
		List<String> adapterTypes = new ArrayList<String>();
		adapterTypes.add("RTC");
		return adapterTypes;
	}

}
