import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.hp.qc.synchronizer.rtcadapter.RTCDefectManager;
import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.ibm.team.repository.common.IItemHandle;
import com.ibm.team.workitem.client.IWorkItemWorkingCopyManager;
import com.ibm.team.workitem.client.WorkItemWorkingCopy;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.ICategory;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.IWorkItemHandle;


public class CreateWI {

	public static void main(String[] args) throws ParseException {
		
		/*try {
			System.out.println(RTCDefectManager.rtcDateFormat.format("2014-07-16 00:42:31.458"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		String jazzUrl = "https://192.168.0.4:9443/ccm/";
		String projectAreaName = "Demo2";
		System.out.println("Connecting to RTC");
		try {
			boolean connected = RTCManager.connect("karawalla", "letmein", jazzUrl);
			if(connected){
				RTCManager.loadProjectAreaByname(projectAreaName);
				System.out.println("Connected to Project Area:" + projectAreaName);
				IWorkItem wi = RTCManager.getWorkItemById("47");
				SimpleDateFormat rtcDateFormat = new SimpleDateFormat(
						"EEE MMM dd HH:mm:ss zzz yyyy");
				Timestamp creationDate =  new Timestamp(rtcDateFormat.parse("Mon Aug 18 12:00:00 CDT 2014").getTime());
				System.out.println(creationDate);
				System.out.println("DD" + wi.getDueDate());
				
				
				IWorkItem eWI = RTCManager.getEditableWorkItem(wi);
				
				List<IAttribute> attrs = RTCManager.getAttributesForDefects();
			
				for (IAttribute attr : attrs) {
					try {
						System.out.println(attr.getDisplayName() + "," +  attr.getAttributeType() + ", " + wi.getValue(attr).toString());
						if(attr.getAttributeType().equalsIgnoreCase("contributor")){
							RTCManager.printEnumerationLiteral(attr);
						}
					/*	if(attr.getAttributeType().equalsIgnoreCase("category")){
							System.out.println(((ICategory)RTCManager.getItem((IItemHandle) wi.getValue(attr))).getName());
							
						}
						if (attr.getDisplayName().equals("catr101")) {
							List<String> tags = new ArrayList<String>();
							tags.add("tageone");
							tags.add("tagetwo");
							
							eWI.setValue(attr, tags);
							
						} else if(attr.getDisplayName().equalsIgnoreCase("summary")){
							eWI.setValue(attr, "updated summary again");
						} else if(attr.getDisplayName().equalsIgnoreCase("priority")){
							eWI.setValue(attr, RTCManager.getMatchingEnumerationLiteral(attr, "medium").getIdentifier2());
						}else if(attr.getDisplayName().equalsIgnoreCase("severity")){
							eWI.setValue(attr, RTCManager.getMatchingEnumerationLiteral(attr, "major").getIdentifier2());
						}*/
					} catch (Exception e) {
						//e.printStackTrace();
						System.err.println(attr.getDisplayName() + "=" + e.getLocalizedMessage());
					}
				}
				
				
				
			//	System.out.println(RTCManager.saveWorkItem(eWI, null));
				
				RTCManager.getRequiredAttributes();
				RTCManager.getContributorListItems(null);
				//System.out.println(RTCManager.getWorkItemModifiedBy(wi, null));
				//System.out.println(RTCManager.getWorkItemOwnedBy(wi, null));
				//System.out.println(RTCManager.getWorkItemPriority(wi, null));
				
		//		RTCManager.getCategoryListItems();
//				RTCManager.getContributorListItems();
			//	RTCManager.printAttr();
				//RTCManager.createNewDefect("");
				//RTCManager.updateWorkItem("28", "Test me");
				//RTCManager.deleteWorkItem("30");
				RTCManager.disconnect();
			}
			else
				System.out.println("Connection Failed to:" + jazzUrl);
			
		} catch (Exception e) { 
			e.printStackTrace();
		}

	}

}
