import java.util.Iterator;
import java.util.List;

import com.hp.qc.synchronizer.rtcadapter.rtc.RTCManager;
import com.ibm.team.workitem.common.model.IAttribute;


public class GetAllDefects {

	public static void main(String[] args) {
		String jazzUrl = "https://192.168.0.16:9443/ccm";
		String projectAreaName = "Demo1";
		System.out.println("Connecting to RTC");
		try {
			boolean connected = RTCManager.connect("karawalla", "letmein", jazzUrl);
			if(connected){
				RTCManager.loadProjectAreaByname(projectAreaName);
				System.out.println("Connected to Project Area:" + projectAreaName);
				RTCManager.getAllDefectsForLoadedProject();
				List<IAttribute> attrs = RTCManager.getAttributesForDefects();
				for (IAttribute iAttribute : attrs) {
					
					System.out.println(iAttribute.getDisplayName() + ":" + iAttribute.getAttributeType() + ":" + iAttribute.isBuiltIn() + ":" + iAttribute.isReadOnly() + ":" + iAttribute.isAuditable() + ":" + iAttribute.isInternal() + ":" + iAttribute.isUnmanaged() + ":" + iAttribute.isImmutable());
				}
			}
			else
				System.out.println("Connection Failed to:" + jazzUrl);
			
		} catch (Exception e) { 
			e.printStackTrace();
		}

	}

}
